package modle;

public class Kejian {
	public String cid="";
	public String filename="";
	public String title="";
	public String explain="";
	public String time="";
	public Kejian(String cid,String filename,String title,String content,String time)
	{
		this.cid=cid;
		this.filename=filename;
		this.title=title;
		this.explain=content;
		this.time=time;
	}

}
