package modle;

public class Error {
	public String num;
	public String n;
	public Error(String num,String n)
	{
		this.num=num;
		this.n=n;
	}

}
