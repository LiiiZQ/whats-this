package modle;

public class Score {

	public String id="";
	public String name="";
	public String num="";
	public String time="";
	
	public Score(String id,String name,String num,String time)
	{
		this.id=id;
		this.name=name;
		this.num=num;
		this.time=time;
	}
	
}
