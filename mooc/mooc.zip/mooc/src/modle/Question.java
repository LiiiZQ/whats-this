package modle;

public class Question {
public String tm;
public String qa;
public String qb;
public String qc;
public String qd;
public String right;
public String explain;

public Question(String tm,String QA,String QB,String QC,String QD,String right,String explain)
{
this.tm=tm;
this.qa=QA;
this.qb=QB;
this.qc=QC;
this.qd=QD;
this.right=right;
this.explain=explain;
	
}
	
	
	
}
