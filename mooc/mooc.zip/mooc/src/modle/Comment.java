package modle;

public class Comment {

	public String username="";
	public String time="";
	public String content="";
	public String videoID="";
	public Comment(String username,String time,String content,String videoID)
	{
		this.username=username;
		this.time=time;
		this.content=content;
		this.videoID=videoID;
	}
	
	
}
